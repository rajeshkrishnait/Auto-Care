/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication14;

/**
 *
 * @author sande
 */

 import javax.swing.*; 
import java.awt.*; 
import java.awt.event.*; 
  
class MyFrame 
    extends JFrame 
    implements ActionListener { 
  
   
    private Container c; 
    private JLabel title; 
    private JLabel name; 
    private JTextField tname; 
    private JLabel mno; 
    private JTextField tmno; 
     private JLabel city; 
    private JTextField tcity;
     private JLabel state; 
    private JTextField tstate;
      private JLabel admin_id; 
    private JTextField tadmin_id;
   
      private JLabel pincode; 
    private JTextField tpincode;
    private JLabel add; 
    private JTextArea tadd; 
    private JCheckBox term; 
    private JButton sub; 
    private JButton reset; 
    private JTextArea tout; 
    private JLabel res; 
    private JTextArea resadd; 
  

    public MyFrame() 
    { 
        setTitle("Admin Registration Form"); 
        setBounds(300, 90, 700, 700); 
        setDefaultCloseOperation(EXIT_ON_CLOSE); 
        setResizable(false); 
  
        c = getContentPane(); 
        c.setLayout(null); 
  
        title = new JLabel("Admin Registration Form"); 
        title.setFont(new Font("Arial", Font.PLAIN, 30)); 
        title.setSize(370, 30); 
        title.setLocation(230, 30); 
        c.add(title); 
        
        admin_id = new JLabel("admin id"); 
        admin_id.setFont(new Font("Arial", Font.PLAIN, 20)); 
        admin_id.setSize(100, 20); 
        admin_id.setLocation(100, 100); 
        c.add(admin_id); 
  
        tadmin_id = new JTextField(); 
        tadmin_id.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tadmin_id.setSize(190, 20); 
        tadmin_id.setLocation(250, 100); 
        c.add(tadmin_id);
  
        name = new JLabel("workshop Name"); 
        name.setFont(new Font("Arial", Font.PLAIN, 20)); 
        name.setSize(250, 20); 
        name.setLocation(100, 150); 
        c.add(name); 
  
        tname = new JTextField(); 
        tname.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tname.setSize(190, 20); 
        tname.setLocation(250, 150); 
        c.add(tname); 
  
        mno = new JLabel("Mobile"); 
        mno.setFont(new Font("Arial", Font.PLAIN, 20)); 
        mno.setSize(100, 20); 
        mno.setLocation(100, 200); 
        c.add(mno); 
  
        tmno = new JTextField(); 
        tmno.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tmno.setSize(190, 20); 
        tmno.setLocation(250, 200); 
        c.add(tmno); 
  
       
        
         
  
       
  
        add = new JLabel("Address"); 
        add.setFont(new Font("Arial", Font.PLAIN, 20)); 
        add.setSize(100, 20); 
        add.setLocation(100, 250); 
        c.add(add); 
  
        tadd = new JTextArea(); 
        tadd.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tadd.setSize(190, 75); 
        tadd.setLocation(250, 250); 
        tadd.setLineWrap(true); 
        c.add(tadd); 
        
        
        city = new JLabel("city"); 
        city.setFont(new Font("Arial", Font.PLAIN, 20)); 
        city.setSize(100, 20); 
        city.setLocation(100, 350); 
        c.add(city); 
  
        tcity = new JTextField(); 
        tcity.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tcity.setSize(190, 20); 
        tcity.setLocation(250, 350); 
        c.add(tcity);
        
        state = new JLabel("state"); 
        state.setFont(new Font("Arial", Font.PLAIN, 20)); 
        state.setSize(100, 20); 
        state.setLocation(100, 400); 
        c.add(state); 
  
        tstate = new JTextField(); 
        tstate.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tstate.setSize(190, 20); 
        tstate.setLocation(250, 400); 
        c.add(tstate);
        
        
        
         pincode = new JLabel("pincode"); 
        pincode.setFont(new Font("Arial", Font.PLAIN, 20)); 
        pincode.setSize(100, 20); 
        pincode.setLocation(100, 450); 
        c.add(pincode); 
  
        tpincode = new JTextField(); 
        tpincode.setFont(new Font("Arial", Font.PLAIN, 15)); 
        tpincode.setSize(190, 20); 
        tpincode.setLocation(250, 450); 
        c.add(tpincode);
        
  
        term = new JCheckBox("Accept Terms And Conditions."); 
        term.setFont(new Font("Arial", Font.PLAIN, 15)); 
        term.setSize(250, 20); 
        term.setLocation(250, 500); 
        c.add(term); 
  
        sub = new JButton("Register"); 
        sub.setFont(new Font("Arial", Font.PLAIN, 15)); 
        sub.setSize(100, 20); 
        sub.setLocation(270, 550); 
        sub.addActionListener(this); 
        c.add(sub); 
  
      
  
        setVisible(true); 
    } 
   
    public void actionPerformed(ActionEvent e) 
    { 
        if (e.getSource() == sub) { 
            if (term.isSelected()) { 
                String data = "Admin_id : " + tadmin_id.getText() +"\n";
                String data1= "Workshop name : "  + tname.getText() + "\n";
                String data2 = "Contact : " + tmno.getText() + "\n"; 
               
                String data3 = "Address : " + tadd.getText()+ "\n"; 
                String data4 = "City : " + tcity.getText() + "\n" ; 
                String data5 = "State : " + tstate.getText()  + "\n";
                String data6 = "Pincode : " + tpincode.getText() + "\n";
                
                
                tout.setText(data + data1 + data2 + data3 + data4 + data5 + data6); 
                tout.setEditable(false); 
                res.setText("Registration Successfully.."); 
            } 
            else { 
                tout.setText(""); 
                resadd.setText(""); 
                res.setText("Please accept the"
                            + " terms & conditions.."); 
            } 
        } 
  
        else if (e.getSource() == reset) { 
            String def = ""; 
            tname.setText(def); 
            tstate.setText(def); 
            tcity.setText(def); 
            tpincode.setText(def);
            tadmin_id.setText(def);
            
            
            
            tadd.setText(def); 
            tmno.setText(def); 
            res.setText(def); 
            tout.setText(def); 
            term.setSelected(false); 
           
            resadd.setText(def); 
        } 
    } 
} 
  

class JavaApplication14 { 
  
    public static void main(String[] args) throws Exception 
    { 
        MyFrame f = new MyFrame(); 
    } 
}
